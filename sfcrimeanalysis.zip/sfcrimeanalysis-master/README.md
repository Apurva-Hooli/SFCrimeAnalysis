# sfcrimeanalysis
Apurva Hooli's assignment of crime analysis in the City of San Francisco

This repo contains all the files necessary to run the SF Crime data analysis on tableau. Due to size restrictions, the raw data CSV files are compressed into ZIP format. 

If you are cloning this repo, please ensure to unzip the raw files so that the data is available for the tableau dashboard.
